"""
🔍 ابزار بازبینی خودکار ربات نورا

سه بررسی حیاتی:
  ۱) تداخل ترتیب روتر (prefix زودتر، دکمه دیرتر را نبلعد)
  ۲) پوشش دکمه‌ها (هر callback_data هندلر داشته باشد)
  ۳) امنیت (SQL injection، except خالی، طول callback)

اجرا:  py tools/audit.py
"""
import re
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
SKIP = {"doctor.py", "guard.py"}


def _router_body():
    src = (BASE / "main.py").read_text(encoding="utf-8")
    i = src.index("def handle_callback")
    j = src.index("def auto_like")
    return src[i:j]


def check_router_order():
    body = _router_body()
    rules = []
    for n, line in enumerate(body.split("\n")):
        m = re.search(r'if data == "([^"]+)"', line)
        if m:
            rules.append(("eq", m.group(1), n))
        m = re.search(r'if data\.startswith\("([^"]+)"\)', line)
        if m:
            rules.append(("pre", m.group(1), n))

    problems = []
    for j, (k2, v2, _) in enumerate(rules):
        for k1, v1, _ in rules[:j]:
            if k1 == "pre" and v2.startswith(v1):
                problems.append(f"'{v1}' (زودتر) → '{v2}' را می‌بلعد")

    seen = {}
    for k, v, ln in rules:
        seen.setdefault((k, v), []).append(ln)
    dups = {k: v for k, v in seen.items() if len(v) > 1}

    print(f"\n[۱] ترتیب روتر — {len(rules)} قانون")
    if problems:
        print(f"  ❌ {len(problems)} تداخل:")
        for p in dict.fromkeys(problems):
            print("     ", p)
    else:
        print("  ✅ هیچ تداخلی نیست")
    if dups:
        print(f"  ⚠️ قوانین تکراری: {dups}")
    return len(problems)


def check_button_coverage():
    emitted = set()
    for p in BASE.glob("*.py"):
        if p.name in SKIP:
            continue
        for i, line in enumerate(p.read_text(encoding="utf-8").split("\n"), 1):
            for m in re.finditer(r'"callback_data":\s*f?"([^"]*)"', line):
                emitted.add((m.group(1), p.name, i))

    body = _router_body()
    eqs = set(re.findall(r'if data == "([^"]+)"', body))
    # 🆕 فاز ۱۸: پشتیبانی از  if data in ("a", "b", ...)
    for grp in re.findall(r'if data in \(([^)]*)\)', body, re.S):
        eqs |= set(re.findall(r'"([^"]+)"', grp))
    pres = re.findall(r'if data\.startswith\("([^"]+)"\)', body)
    for grp in re.findall(r'if data\.startswith\(\(([^)]*)\)\)', body):
        pres += re.findall(r'"([^"]+)"', grp)

    def handled(v):
        c = re.sub(r"\{[^}]*\}", "X", v)
        return c in eqs or any(c.startswith(p) for p in pres)

    missing = sorted({(c, f, i) for c, f, i in emitted if not handled(c)})
    print(f"\n[۲] پوشش دکمه‌ها — {len({c for c, _, _ in emitted})} دکمه یکتا")
    if missing:
        print(f"  ❌ {len(missing)} دکمه بدون هندلر:")
        for c, f, i in missing:
            print(f"      {c!r}  ({f}:{i})")
    else:
        print("  ✅ همه دکمه‌ها هندلر دارند")
    return len(missing)


def check_security():
    issues = []
    for p in BASE.glob("*.py"):
        src = p.read_text(encoding="utf-8")
        for i, line in enumerate(src.split("\n"), 1):
            if re.match(r"\s*except\s*:", line):
                issues.append(f"except خالی — {p.name}:{i}")
            for m in re.finditer(r'"callback_data":\s*f?"([^"]*)"', line):
                approx = re.sub(r"\{[^}]*\}", "999999", m.group(1))
                if len(approx.encode()) > 64:
                    issues.append(f"callback بلند — {p.name}:{i}")
    print("\n[۳] امنیت")
    if issues:
        print(f"  ❌ {len(issues)} مورد:")
        for x in issues[:15]:
            print("     ", x)
    else:
        print("  ✅ هیچ except خالی / callback بلند")
    return len(issues)


def main():
    print("=" * 58)
    print("🔍 بازبینی خودکار ربات نورا")
    print("=" * 58)
    bad = check_router_order() + check_button_coverage() + check_security()
    print("\n" + "=" * 58)
    print("🎉 همه بررسی‌ها پاس شد" if not bad else f"⚠️ مجموع مشکلات: {bad}")
    print("=" * 58)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
