"""
🔬 بازبینی عمیق کل کد — ربات نورا

بررسی‌هایی که ابزار audit.py پوشش نمی‌دهد:
  ۱) SQL injection (f-string با متغیر غیر allowlist)
  ۲) ستون‌های استفاده‌شده که در schema نیستند
  ۳) توابع فراخوانی‌شده که وجود ندارند
  ۴) import های شکسته / حلقوی
  ۵) state هایی که هندلر ندارند
  ۶) جدول‌های استفاده‌شده که ساخته نمی‌شوند
  ۷) کلیدهای تنظیمات ناسازگار

اجرا:  py tools/deepcheck.py
"""
import ast
import re
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
PY = sorted(p for p in BASE.glob("*.py"))
ISSUES = []


def add(kind, msg):
    ISSUES.append((kind, msg))


# ═══════════ ۱) SQL injection ═══════════
def check_sql():
    print("\n[۱] بررسی SQL injection")
    risky = []
    for p in PY:
        src = p.read_text(encoding="utf-8")
        for i, line in enumerate(src.split("\n"), 1):
            if not re.search(r'db_(execute|scalar)\(\s*f["\']', line):
                continue
            # متغیرهای داخل f-string
            vars_in = re.findall(r"\{([a-zA-Z_][a-zA-Z_0-9]*)", line)
            # allowlist: نام جدول/ستون ثابت یا متغیر گاردشده
            ctx = "\n".join(src.split("\n")[max(0, i - 40):i])
            safe = True
            for v in vars_in:
                # آیا قبلش گارد شده؟
                guarded = (
                    re.search(rf"if {v} not in ", ctx)
                    or re.search(rf"if {v} in ", ctx)
                    or re.search(rf"{v}\s*=\s*['\"]", ctx)
                    or re.search(rf"for {v}[ ,]", ctx)
                    or re.search(rf"{v}\s*=\s*\"[a-z_]+\" if ", ctx)
                    or v in ("name", "tbl", "col", "key", "field", "where",
                             "n", "days", "table")
                )
                if not guarded:
                    safe = False
            if not safe:
                risky.append(f"{p.name}:{i}  {line.strip()[:80]}")
    if risky:
        print(f"  ⚠️ {len(risky)} مورد نیاز به بررسی دستی:")
        for r in risky[:10]:
            print("     ", r)
        for r in risky:
            add("SQL", r)
    else:
        print("  ✅ همه f-string های SQL گاردشده‌اند")


# ═══════════ ۲) ستون‌های ناموجود ═══════════
def collect_schemas():
    """همه ستون‌های تعریف‌شده در schema ها"""
    cols = {}
    for p in PY:
        src = p.read_text(encoding="utf-8")
        for m in re.finditer(r'ensure_table\(\s*"([a-z_]+)"\s*,\s*([A-Z_]+)',
                             src):
            tbl, var = m.group(1), m.group(2)
            sm = re.search(rf"{var}\s*=\s*\{{(.*?)\n\}}", src, re.S)
            if sm:
                cols.setdefault(tbl, set()).update(
                    re.findall(r'"([a-z_0-9]+)":', sm.group(1)))
        for m in re.finditer(r'TABLE_SCHEMAS\s*=\s*\{(.*?)\n\}', src, re.S):
            blk = m.group(1)
            for tm in re.finditer(r'"([a-z_]+)":\s*\{(.*?)\n    \}', blk, re.S):
                cols.setdefault(tm.group(1), set()).update(
                    re.findall(r'"([a-z_0-9]+)":', tm.group(2)))
    for t in cols:
        cols[t].add("id")
    return cols


def check_columns():
    print("\n[۲] بررسی ستون‌های استفاده‌شده")
    schemas = collect_schemas()
    print(f"  📋 {len(schemas)} جدول با schema پیدا شد")
    bad = []
    for p in PY:
        src = p.read_text(encoding="utf-8")
        # UPDATE x SET col=?
        for m in re.finditer(r"UPDATE\s+([a-z_]+)\s+SET\s+([a-z_0-9]+)\s*=",
                             src, re.I):
            tbl, col = m.group(1), m.group(2)
            if tbl in schemas and col not in schemas[tbl]:
                bad.append(f"{p.name}: UPDATE {tbl} SET {col} — ستون نیست")
    if bad:
        print(f"  ❌ {len(bad)} ستون ناموجود:")
        for b in dict.fromkeys(bad):
            print("     ", b)
            add("COLUMN", b)
    else:
        print("  ✅ همه ستون‌ها در schema هستند")


# ═══════════ ۳) توابع ناموجود ═══════════
def check_calls():
    print("\n[۳] بررسی فراخوانی توابع بین ماژول‌ها")
    defs = {}
    for p in PY:
        try:
            tree = ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError as e:
            add("SYNTAX", f"{p.name}:{e.lineno} {e.msg}")
            continue
        defs[p.stem] = {n.name for n in ast.walk(tree)
                        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        defs[p.stem] |= {n.name for n in ast.walk(tree)
                         if isinstance(n, ast.ClassDef)}
        # متغیرهای سطح ماژول
        defs[p.stem] |= {t.id for n in tree.body
                         if isinstance(n, ast.Assign)
                         for t in n.targets if isinstance(t, ast.Name)}

    alias = {}
    for p in PY:
        src = p.read_text(encoding="utf-8")
        for m in re.finditer(r"^import ([a-z_]+) as ([a-z_]+)", src, re.M):
            alias.setdefault(p.stem, {})[m.group(2)] = m.group(1)

    bad = []
    for p in PY:
        src = p.read_text(encoding="utf-8")
        amap = alias.get(p.stem, {})
        for m in re.finditer(r"\b([a-z_]+)\.([a-z_A-Z0-9]+)\s*\(", src):
            mod, fn = m.group(1), m.group(2)
            real = amap.get(mod, mod)
            if real not in defs:
                continue
            if fn.startswith("_") and fn not in defs[real]:
                continue
            if fn not in defs[real]:
                ln = src[:m.start()].count("\n") + 1
                # اگر هم‌نام یک متغیر محلی باشد، فراخوانی ماژول نیست
                if re.search(rf"^\s+{mod}\s*=", src, re.M):
                    continue
                # متدهای عمومی دیکشنری/لیست
                if fn in ("get", "items", "keys", "values", "append",
                          "pop", "update", "strip", "split", "join"):
                    continue
                bad.append(f"{p.name}:{ln}  {mod}.{fn}() در {real}.py نیست")
    if bad:
        print(f"  ❌ {len(bad)} فراخوانی مشکوک:")
        uniq = list(dict.fromkeys(bad))
        for b in uniq[:12]:
            print("     ", b)
        for b in uniq:
            add("CALL", b)
    else:
        print("  ✅ همه فراخوانی‌های بین‌ماژولی معتبرند")


# ═══════════ ۴) import ═══════════
def check_imports():
    print("\n[۴] بررسی import ها")
    names = {p.stem for p in PY}
    bad = []
    for p in PY:
        src = p.read_text(encoding="utf-8")
        for m in re.finditer(r"^\s*(?:from|import)\s+([a-z_]+)", src, re.M):
            mod = m.group(1)
            if mod in names or mod in sys.stdlib_module_names:
                continue
            if mod in ("requests", "openpyxl", "PIL", "dotenv", "qrcode",
                       "arabic_reshaper", "bidi"):
                continue
            ln = src[:m.start()].count("\n") + 1
            bad.append(f"{p.name}:{ln}  import {mod}")
    if bad:
        print(f"  ⚠️ {len(bad)} import ناشناخته:")
        for b in bad[:8]:
            print("     ", b)
    else:
        print("  ✅ همه import ها معتبرند")


# ═══════════ ۵) state ها ═══════════
def check_states():
    print("\n[۵] بررسی state ها")
    states = {}
    for p in PY:
        src = p.read_text(encoding="utf-8")
        for m in re.finditer(r'^(STATE_[A-Z_0-9]+)\s*=\s*"([a-z_0-9]+)"',
                             src, re.M):
            states[m.group(1)] = (p.stem, m.group(2))
    main = (BASE / "main.py").read_text(encoding="utf-8")
    unhandled = []
    for var, (mod, val) in states.items():
        if var in main or f'"{val}"' in main:
            continue
        unhandled.append(f"{mod}.{var} = '{val}' — در main.py هندل نشده")
    print(f"  📋 {len(states)} state تعریف شده")
    if unhandled:
        print(f"  ❌ {len(unhandled)} state بدون هندلر:")
        for u in unhandled:
            print("     ", u)
            add("STATE", u)
    else:
        print("  ✅ همه state ها هندلر دارند")


# ═══════════ ۶) جدول‌ها ═══════════
def check_tables():
    print("\n[۶] بررسی جدول‌ها")
    created = set()
    for p in PY:
        src = p.read_text(encoding="utf-8")
        created |= set(re.findall(r'ensure_table\(\s*"([a-z_]+)"', src))
        for m in re.finditer(r'TABLE_SCHEMAS\s*=\s*\{(.*?)\n\}', src, re.S):
            created |= set(re.findall(r'"([a-z_]+)":\s*\{', m.group(1)))
        # CREATE TABLE مستقیم (مثل users)
        created |= set(re.findall(
            r'CREATE TABLE (?:IF NOT EXISTS )?([a-z_]+)', src))
    used = set()
    for p in PY:
        src = p.read_text(encoding="utf-8")
        used |= set(re.findall(r"FROM\s+([a-z_]{4,})", src))
        used |= set(re.findall(r"INSERT\s+(?:OR\s+\w+\s+)?INTO\s+([a-z_]{4,})",
                               src, re.I))
        used |= set(re.findall(r"UPDATE\s+([a-z_]{4,})\s+SET", src, re.I))
    sqlkw = {"select", "where", "table", "sqlite_master", "pragma"}
    missing = {t for t in used - created if t not in sqlkw}
    print(f"  📋 ساخته‌شده: {len(created)}  |  استفاده‌شده: {len(used)}")
    if missing:
        print(f"  ❌ {len(missing)} جدول استفاده می‌شود ولی ساخته نمی‌شود:")
        for t in sorted(missing):
            print("     ", t)
            add("TABLE", t)
    else:
        print("  ✅ همه جدول‌های استفاده‌شده ساخته می‌شوند")


# ═══════════ ۷) پول ═══════════
def check_money():
    print("\n[۷] بررسی واحد پول")
    bad = []
    for p in PY:
        if p.name in ("config.py", "tools"):
            continue
        src = p.read_text(encoding="utf-8")
        for i, line in enumerate(src.split("\n"), 1):
            # نمایش مستقیم مبلغ خام بدون تبدیل
            if re.search(r'\{[a-z_]*(amount|price|cost)[a-z_]*\s*:?,?\}?\s*'
                         r'\}\s*(تومان|ریال)', line):
                if "fmt" not in line and "money" not in line:
                    bad.append(f"{p.name}:{i} {line.strip()[:70]}")
    if bad:
        print(f"  ⚠️ {len(bad)} نمایش مبلغ بدون تبدیل:")
        for b in bad[:8]:
            print("     ", b)
            add("MONEY", b)
    else:
        print("  ✅ همه مبالغ از تابع تبدیل عبور می‌کنند")


def main():
    print("=" * 60)
    print("🔬 بازبینی عمیق کل کد — ربات نورا")
    print("=" * 60)
    print(f"📦 {len(PY)} ماژول")
    check_sql()
    check_columns()
    check_calls()
    check_imports()
    check_states()
    check_tables()
    check_money()

    print("\n" + "=" * 60)
    hard = [i for i in ISSUES if i[0] in ("SYNTAX", "COLUMN", "STATE",
                                          "TABLE", "CALL")]
    if hard:
        print(f"❌ {len(hard)} مشکل جدی:")
        for k, m in hard:
            print(f"   [{k}] {m}")
    else:
        print("🎉 هیچ مشکل جدی پیدا نشد")
    soft = [i for i in ISSUES if i not in hard]
    if soft:
        print(f"\n⚠️ {len(soft)} مورد برای بررسی دستی")
    print("=" * 60)
    return 1 if hard else 0


if __name__ == "__main__":
    sys.exit(main())
