# -*- coding: utf-8 -*-
"""🔍 اسکن ۵ — SQL: ستون ناموجود، جدول ناموجود، تعداد پارامتر"""
import ast, re, pathlib, sqlite3, os, sys

os.environ.setdefault("BOT_TOKEN", "0:t")
os.environ.setdefault("SUPER_ADMIN_ID", "1")
os.environ["DB_PATH"] = "/tmp/scan5.db"
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/scan5.db" + e)
    except OSError:
        pass

sys.path.insert(0, ".")
import bale_api as _b
_b.api = lambda *a, **k: {"ok": True, "result": {}}
_b.send = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
_b.send_or_edit = _b.send
_b.send_photo = _b.send_document = _b.send

import database
database.init_db()
for mod, fn in (("certgen", "init_cert_tables"),
                ("attendance", "init_attendance_tables"),
                ("events", "init_event_tables"),
                ("forms", "init_form_tables"),
                ("club", "init_club_tables"),
                ("profile", "init_profile_extra"),
                ("certcenter", "init_tables"),
                ("certverify", "init_tables"),
                ("survey", "init_tables"),
                ("attendance_auto", "init_tables"),
                ("payments", "init_payment_tables"),
                ("tickets", "init_ticket_tables"),
                ("ads", "init_ads_tables"),
                ("paylink", "init_paylink_tables"),
                ("payplan", "init_payplan_tables"),
                ("about", "init_about_tables"),
                ("lottery", "init_lottery_tables"),
                ("occasions", "init_occasion_tables"),
                ("activity_log", "init_log_tables"),
                ("permissions", "init_perm_tables"),
                ("infra_fee", "init_infra_tables")):
    try:
        m = __import__(mod)
        f = getattr(m, fn, None)
        if f:
            f()
    except Exception as e:
        print(f"⚠️ {mod}.{fn}: {str(e)[:70]}")

con = sqlite3.connect("/tmp/scan5.db")
cur = con.cursor()
tables = {r[0] for r in cur.execute(
    "SELECT name FROM sqlite_master WHERE type='table'")}
cols = {}
for t in tables:
    try:
        cols[t] = {r[1] for r in cur.execute(f"PRAGMA table_info({t})")}
    except Exception:
        pass

print(f"\n📋 {len(tables)} جدول ساخته شد\n")

# ── استخراج SQL از کد ──
SQLRE = re.compile(
    r'(SELECT|INSERT\s+(?:OR\s+\w+\s+)?INTO|UPDATE|DELETE\s+FROM)\s',
    re.I)
bad_tbl, bad_col, bad_par = [], [], []

for f in sorted(pathlib.Path(".").glob("*.py")):
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not isinstance(n, ast.Call):
            continue
        fname = getattr(n.func, "attr", None) or \
            getattr(n.func, "id", None)
        if fname not in ("db_execute", "db_scalar", "_dx", "_dbx"):
            continue
        if not n.args:
            continue
        a0 = n.args[0]
        # فقط رشته‌های ثابت (JoinedStr = f-string → رد)
        parts = []
        if isinstance(a0, ast.Constant) and isinstance(a0.value, str):
            parts = [a0.value]
        elif isinstance(a0, ast.BinOp):
            for sub in ast.walk(a0):
                if isinstance(sub, ast.Constant) and \
                        isinstance(sub.value, str):
                    parts.append(sub.value)
        if not parts:
            continue
        sql = " ".join(parts)
        if not SQLRE.search(sql):
            continue

        # جدول‌ها
        for m in re.finditer(
                r'(?:FROM|INTO|UPDATE|JOIN)\s+([a-z_][a-z0-9_]*)',
                sql, re.I):
            tb = m.group(1).lower()
            if tb in ("select", "set", "values", "on", "where",
                      "as", "sqlite_master"):
                continue
            if tb not in tables and tb not in cols:
                bad_tbl.append((f.name, n.lineno, tb, sql[:70]))

        # تعداد ? در برابر تاپل
        nq = sql.count("?")
        if len(n.args) >= 2 and nq:
            a1 = n.args[1]
            if isinstance(a1, ast.Tuple):
                if not any(isinstance(e, ast.Starred)
                           for e in a1.elts):
                    if len(a1.elts) != nq:
                        bad_par.append(
                            (f.name, n.lineno, nq, len(a1.elts),
                             sql[:60]))
        elif nq and len(n.args) < 2:
            bad_par.append((f.name, n.lineno, nq, 0, sql[:60]))

print("═══ جدول ناموجود ═══")
seen = set()
for x in bad_tbl:
    k = (x[0], x[1], x[2])
    if k in seen:
        continue
    seen.add(k)
    print(f"🔴 {x[0]}:{x[1]}  جدول «{x[2]}»")
if not seen:
    print("✅ هیچ")

print("\n═══ تعداد ? با پارامترها نمی‌خواند ═══")
seen2 = set()
for x in bad_par:
    k = (x[0], x[1])
    if k in seen2:
        continue
    seen2.add(k)
    print(f"🔴 {x[0]}:{x[1]}  {x[2]}× ? ولی {x[3]} مقدار  | {x[4]}")
if not seen2:
    print("✅ هیچ")
con.close()
