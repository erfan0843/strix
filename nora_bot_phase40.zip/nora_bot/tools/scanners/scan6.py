# -*- coding: utf-8 -*-
"""🔍 اسکن ۶ — راه‌اندازی واقعی مثل main.py + ستون‌های ناموجود"""
import os, re, sys, ast, pathlib, sqlite3

os.environ.setdefault("BOT_TOKEN", "0:t")
os.environ.setdefault("SUPER_ADMIN_ID", "1")
os.environ["DB_PATH"] = "/tmp/scan6.db"
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/scan6.db" + e)
    except OSError:
        pass
sys.path.insert(0, ".")

import bale_api as _b
_b.api = lambda *a, **k: {"ok": True, "result": {}}
_b.send = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
_b.send_or_edit = _b.send
_b.send_photo = _b.send_document = _b.send
_b.get_me = lambda: {"ok": True, "result": {"username": "t"}}

# ── دقیقاً همان توابعی که main.py صدا می‌زند ──
main = pathlib.Path("main.py").read_text(encoding="utf-8")
calls = re.findall(r"^\s{4}(\w+)\.(init_\w+|seed_\w+)\(\)", main, re.M)
alias = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in alias.items()}

import database
database.init_db()
done, fail = 0, []
for mod_alias, fn in calls:
    real = rev.get(mod_alias, mod_alias)
    try:
        m = __import__(real)
        f = getattr(m, fn, None)
        if not f:
            fail.append(f"{real}.{fn} — تابع نیست")
            continue
        f()
        done += 1
    except Exception as e:
        fail.append(f"{real}.{fn} — {type(e).__name__}: {str(e)[:60]}")

print(f"═══ راه‌اندازی: {done} موفق ═══")
for x in fail:
    print("🔴", x)
if not fail:
    print("✅ همه بی‌خطا")

con = sqlite3.connect("/tmp/scan6.db")
cur = con.cursor()
tables = {r[0] for r in cur.execute(
    "SELECT name FROM sqlite_master WHERE type='table'")}
cols = {t: {r[1] for r in cur.execute(f"PRAGMA table_info({t})")}
        for t in tables}
print(f"\n📋 {len(tables)} جدول")

# ── ستون‌های استفاده‌شده که وجود ندارند ──
bad = []
for f in sorted(pathlib.Path(".").glob("*.py")):
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not isinstance(n, ast.Call):
            continue
        fn = getattr(n.func, "attr", None) or getattr(n.func, "id", None)
        if fn not in ("db_execute", "db_scalar", "_dx", "_dbx"):
            continue
        if not n.args:
            continue
        a0 = n.args[0]
        parts = []
        if isinstance(a0, ast.Constant) and isinstance(a0.value, str):
            parts = [a0.value]
        elif isinstance(a0, ast.BinOp):
            for s in ast.walk(a0):
                if isinstance(s, ast.Constant) and \
                        isinstance(s.value, str):
                    parts.append(s.value)
        if not parts:
            continue
        sql = " ".join(parts)

        # SELECT col FROM tbl / UPDATE tbl SET col=
        m = re.search(r'\bFROM\s+([a-z_][a-z0-9_]*)', sql, re.I)
        tb = m.group(1).lower() if m else None
        if not tb:
            m = re.search(r'\bUPDATE\s+([a-z_][a-z0-9_]*)', sql, re.I)
            tb = m.group(1).lower() if m else None
        if not tb or tb not in cols:
            continue
        if re.search(r'\bJOIN\b', sql, re.I):
            continue          # چند جدول → مبهم
        known = cols[tb]
        # WHERE col=?  و  SET col=?
        for m2 in re.finditer(
                r'(?:WHERE|AND|OR|SET|,)\s+([a-z_][a-z0-9_]*)\s*=',
                sql, re.I):
            c = m2.group(1).lower()
            if c in ("and", "or", "not", "where", "set"):
                continue
            if c not in known:
                bad.append((f.name, n.lineno, tb, c, sql[:60]))

print("\n═══ ستون ناموجود ═══")
seen = set()
for x in bad:
    k = (x[0], x[1], x[3])
    if k in seen:
        continue
    seen.add(k)
    print(f"🔴 {x[0]}:{x[1]}  {x[2]}.{x[3]}  | {x[4]}")
if not seen:
    print("✅ هیچ")
con.close()
