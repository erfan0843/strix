# -*- coding: utf-8 -*-
"""🔍 اسکن ۷ — همهٔ توابع پنل با ورودی خراب صدا زده شوند"""
import os, sys, ast, pathlib, inspect, traceback

os.environ.setdefault("BOT_TOKEN", "0:t")
os.environ.setdefault("SUPER_ADMIN_ID", "1")
os.environ["BOT_USERNAME"] = "t"
os.environ["DB_PATH"] = "/tmp/scan7.db"
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/scan7.db" + e)
    except OSError:
        pass
sys.path.insert(0, ".")

import bale_api as _b
SENT = []
_b.api = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
_b.send = lambda *a, **k: (SENT.append(a), {"ok": True,
                                            "result": {"message_id": 1}})[1]
_b.send_or_edit = _b.send
_b.send_photo = _b.send_document = _b.send
_b.get_me = lambda: {"ok": True, "result": {"username": "t"}}

import database
database.init_db()
import re
main = pathlib.Path("main.py").read_text(encoding="utf-8")
calls = re.findall(r"^\s{4}(\w+)\.(init_\w+|seed_\w+)\(\)", main, re.M)
alias = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in alias.items()}
for ma, fn in calls:
    try:
        m = __import__(rev.get(ma, ma))
        getattr(m, fn, lambda: None)()
    except Exception:
        pass

# سوپرادمین
database.db_execute(
    "INSERT OR IGNORE INTO users (bale_user_id, first_name, is_admin,"
    " admin_type, profile_status, is_authenticated) VALUES "
    "(1,'ادمین',1,'super_admin','approved',1)")

SKIP_MOD = {"main", "doctor", "config", "database", "bale_api"}
SKIP_FN = {"run", "main", "loop", "poll", "start_bot", "handle_update"}

crashes = []
tested = 0
for f in sorted(pathlib.Path(".").glob("*.py")):
    if f.stem in SKIP_MOD:
        continue
    try:
        mod = __import__(f.stem)
    except Exception as e:
        crashes.append((f.stem, "IMPORT", f"{type(e).__name__}: {e}"))
        continue
    for nm in dir(mod):
        if nm.startswith("_") or nm in SKIP_FN:
            continue
        fn = getattr(mod, nm)
        if not callable(fn) or not inspect.isfunction(fn):
            continue
        if getattr(fn, "__module__", "") != f.stem:
            continue
        try:
            sig = inspect.signature(fn)
        except (ValueError, TypeError):
            continue
        ps = list(sig.parameters.values())
        req = [p for p in ps
               if p.default is inspect.Parameter.empty
               and p.kind in (p.POSITIONAL_ONLY,
                              p.POSITIONAL_OR_KEYWORD)]
        # فقط توابع پنل: (cid, uid, ...)
        if len(req) < 2:
            continue
        if req[0].name not in ("cid",) or req[1].name not in ("uid",):
            continue
        args = [1, 1]
        for p in req[2:]:
            n = p.name.lower()
            if any(k in n for k in ("id", "num", "idx", "page",
                                    "eid", "tid", "rid", "sid")):
                args.append(999999)      # شناسهٔ ناموجود
            else:
                args.append("zzz")
        tested += 1
        try:
            fn(*args)
        except Exception as e:
            crashes.append((f.stem, nm,
                            f"{type(e).__name__}: {str(e)[:80]}"))

print(f"═══ {tested} تابع پنل با ورودی ناموجود آزمایش شد ═══\n")
for m, fn, e in crashes:
    print(f"🔴 {m}.{fn}()  →  {e}")
if not crashes:
    print("✅ هیچ‌کدام استثنا ندادند")
print(f"\nمجموع خطا: {len(crashes)}")
