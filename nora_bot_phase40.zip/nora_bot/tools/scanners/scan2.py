# -*- coding: utf-8 -*-
"""🔍 اسکن ۲ — import های ماژول داخلی که وجود ندارند + وابستگی حلقوی"""
import ast, pathlib, sys

FILES = sorted(pathlib.Path(".").glob("*.py"))
MODS = {f.stem for f in FILES}
graph = {}
missing = []

for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    deps = set()
    for n in ast.walk(t):
        mod = None
        if isinstance(n, ast.Import):
            for al in n.names:
                mod = al.name.split(".")[0]
                if mod in MODS:
                    deps.add(mod)
        elif isinstance(n, ast.ImportFrom) and n.module:
            mod = n.module.split(".")[0]
            if mod in MODS:
                deps.add(mod)
                # آیا نام‌های وارداتی واقعاً وجود دارند؟
                try:
                    src2 = pathlib.Path(mod + ".py").read_text(
                        encoding="utf-8")
                    t2 = ast.parse(src2)
                except Exception:
                    continue
                have = set()
                for n2 in t2.body:
                    if isinstance(n2, (ast.FunctionDef,
                                       ast.AsyncFunctionDef,
                                       ast.ClassDef)):
                        have.add(n2.name)
                    elif isinstance(n2, ast.Assign):
                        for tg in n2.targets:
                            if isinstance(tg, ast.Name):
                                have.add(tg.id)
                    elif isinstance(n2, ast.AnnAssign) and \
                            isinstance(n2.target, ast.Name):
                        have.add(n2.target.id)
                    elif isinstance(n2, (ast.Import, ast.ImportFrom)):
                        for al in n2.names:
                            have.add(al.asname or
                                     al.name.split(".")[0])
                    elif isinstance(n2, ast.Try):
                        for sub in ast.walk(n2):
                            if isinstance(sub, (ast.Import,
                                                ast.ImportFrom)):
                                for al in sub.names:
                                    have.add(al.asname or
                                             al.name.split(".")[0])
                            elif isinstance(sub, ast.Assign):
                                for tg in sub.targets:
                                    if isinstance(tg, ast.Name):
                                        have.add(tg.id)
                for al in n.names:
                    if al.name == "*":
                        continue
                    if al.name not in have:
                        missing.append(
                            f"{f.name}:{n.lineno}  از «{mod}» "
                            f"وارد می‌کند «{al.name}» — پیدا نشد")
    graph[f.stem] = deps

print("═══ import های شکسته ═══")
for m in missing[:25]:
    print("🔴", m)
if not missing:
    print("✅ هیچ")

# حلقهٔ سطح ماژول (فقط import های بالای فایل خطرناک‌اند)
print("\n═══ حلقهٔ وابستگی سطح-ماژول ═══")
top = {}
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    d = set()
    for n in t.body:
        if isinstance(n, ast.Import):
            for al in n.names:
                if al.name.split(".")[0] in MODS:
                    d.add(al.name.split(".")[0])
        elif isinstance(n, ast.ImportFrom) and n.module:
            if n.module.split(".")[0] in MODS:
                d.add(n.module.split(".")[0])
    top[f.stem] = d

cycles = []
def dfs(node, path, seen):
    for nb in top.get(node, ()):
        if nb in path:
            i = path.index(nb)
            cyc = tuple(path[i:] + [nb])
            if cyc not in cycles:
                cycles.append(cyc)
            continue
        if nb in seen:
            continue
        seen.add(nb)
        dfs(nb, path + [nb], seen)

for m in top:
    dfs(m, [m], set())
for c in cycles[:10]:
    print("🔴 حلقه:", " → ".join(c))
if not cycles:
    print("✅ هیچ حلقهٔ سطح-ماژول")
