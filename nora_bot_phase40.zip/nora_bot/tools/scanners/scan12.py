# -*- coding: utf-8 -*-
"""🔍 اسکن ۱۲ — جریان کامل: ثبت‌نام تا گواهینامه"""
import os, sys, re, pathlib

os.environ.update(BOT_TOKEN="0:t", SUPER_ADMIN_ID="1",
                  BOT_USERNAME="t", DB_PATH="/tmp/s12.db")
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/s12.db" + e)
    except OSError:
        pass
sys.path.insert(0, ".")
import bale_api as b
SENT = []
def _s(cid, text="", kb=None, **k):
    SENT.append({"cid": cid, "text": text, "kb": kb})
    return {"ok": True, "result": {"message_id": len(SENT)}}
b.api = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
b.send = _s
b.send_or_edit = _s
b.send_photo = b.send_document = lambda *a, **k: {"ok": True, "result": {}}
b.get_me = lambda: {"ok": True, "result": {"username": "t"}}

import database
database.init_db()
main = pathlib.Path("main.py").read_text(encoding="utf-8")
al = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in al.items()}
for ma, fn in re.findall(r"^\s{4}(\w+)\.(init_\w+|seed_\w+)\(\)",
                         main, re.M):
    try:
        getattr(__import__(rev.get(ma, ma)), fn, lambda: None)()
    except Exception as e:
        print("init:", ma, fn, e)

ok, bad = [], []
def T(name, cond, extra=""):
    (ok if cond else bad).append((name, extra))

database.db_execute(
    "INSERT INTO users (bale_user_id, first_name, last_name,"
    " national_id, mobile, profile_status, is_authenticated,"
    " is_admin, admin_type) VALUES "
    "(1,'س','ا','0012345679','09120000000','approved',1,1,"
    "'super_admin')")
database.db_execute(
    "INSERT INTO users (bale_user_id, first_name, last_name,"
    " national_id, mobile, profile_status, is_authenticated) VALUES "
    "(700,'رضا','ک','0023456787','09121111111','approved',1)")

import events, attendance, certissue, certcenter, certverify
import certgen, jalali

# ── رویداد + ثبت‌نام + حضور + گواهینامه ──
eid = database.db_execute(
    "INSERT INTO events (title, event_type, status, start_date,"
    " has_certificate, has_attendance, cert_doc_no) VALUES "
    "(?,?,?,?,1,1,?)",
    ("کارگاه", "workshop", "published", "1405/05/01", "1421/د"))
T("رویداد ساخته شد", bool(eid))
database.db_execute(
    "INSERT INTO event_registrations (event_id, bale_user_id, status)"
    " VALUES (?,?,'confirmed')", (eid, 700))

import docx
from docx.shared import Mm
d = docx.Document()
d.add_paragraph("{نام} {کدملی} {رویداد} {تاریخ صدور} {شماره نامه}")
d.save("/tmp/s12.docx")
tid = database.db_execute(
    "INSERT INTO cert_templates (name, file_path, kind, is_active,"
    " is_default) VALUES ('t','/tmp/s12.docx','docx',1,1)")

# جلسه و حضور
sid = database.db_execute(
    "INSERT INTO attendance_sessions (event_id, title, session_no,"
    " session_code, method, is_open, points) VALUES "
    "(?,?,1,'12345','code',1,10)", (eid, "ج۱"))
T("جلسه ساخته شد", bool(sid))

# صدور توسط ادمین
cert, err = certissue.issue_one(eid, 700, 1, send_to_user=False)
T("گواهینامه صادر شد", bool(cert), str(err)[:60])
if cert:
    c2 = database.db_execute("SELECT * FROM certificates WHERE id=?",
                             (cert["id"],), fetch="one")
    T("شمارهٔ نامه ثبت شد", c2.get("doc_no") == "1421/د",
      str(c2.get("doc_no")))
    T("کد فردی دارد", bool(c2.get("person_code")))
    T("تاریخ صدور شمسی", str(c2.get("issued_on") or "").startswith("14"),
      str(c2.get("issued_on")))
    T("اعتبار محاسبه شد", bool(c2.get("expires_on")))
    row, why = certverify.find(c2["person_code"])
    T("استعلام با کد فردی", bool(row))
    row2, _ = certverify.find(c2["full_code"])
    T("استعلام با شناسهٔ کامل", bool(row2))
    u = database.db_execute("SELECT total_certificates FROM users"
                            " WHERE bale_user_id=700", fetch="one")
    T("شمارندهٔ کاربر", (u or {}).get("total_certificates", 0) >= 1)

# قفل صدور
SENT.clear()
n0 = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
attendance.issue_certificate(700, 700, eid)
n1 = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
T("🔒 کاربر خودش صادر نمی‌کند", n1 == n0, f"{n0}→{n1}")

# مرکز صدور
iid = certcenter.create_issue(1, "طرح", tid)
certcenter.scan_template(tid)
ask, auto, imgs = certcenter.template_fields(tid)
for k in ask:
    if certcenter.field_kind(k) != "system":
        certcenter.set_value(iid, k, "x")
certcenter.fill_from_event(iid, eid)
rdy, todo = certcenter.issue_ready(certcenter.get_issue(iid))
T("طرح آمادهٔ انتشار", rdy, str(todo))
n2 = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
certcenter.publish(iid, notify=False)
n3 = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
T("🐢 انتشار فایلی نمی‌سازد", n3 == n2, f"{n2}→{n3}")

sh = certcenter.shares(iid)
if sh:
    c3, e3 = certcenter.build_one(iid, sh[0]["id"], notify=False)
    T("مرکز صدور ساخت", bool(c3), str(e3)[:60])

print("\n═══ جریان کامل ═══")
for n, e in ok:
    print(f"  ✅ {n}")
for n, e in bad:
    print(f"  🔴 {n}  {e}")
print(f"\n{len(ok)} موفق · {len(bad)} ناموفق")
