# -*- coding: utf-8 -*-
"""🔬 عمیق ۴ — کدام تابع بی‌محافظ واقعاً از روتر ادمین می‌آید؟"""
import ast, re, pathlib

main = pathlib.Path("main.py").read_text(encoding="utf-8")
FILES = sorted(pathlib.Path(".").glob("*.py"))

# نگاشت: mod_alias → real
al = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in al.items()}

# ── کدام توابع از روتر صدا زده می‌شوند و با چه callbackی ──
route = {}          # (mod, fn) -> [callbacks]
for m in re.finditer(
        r'if data(?:\s*==\s*"([^"]+)"|\.startswith\("([^"]+)"\))'
        r'[^\n]*:\s*\n\s*return (\w+)\.(\w+)\(', main):
    cb = m.group(1) or m.group(2)
    mod = rev.get(m.group(3), m.group(3))
    route.setdefault((mod, m.group(4)), []).append(cb)

# ── آیا آن بخش روتر داخل بلوک ادمین است؟ ──
# main.py معمولاً بخش ادمین را با یک بررسی جدا می‌کند
adm_guard = "is_admin" in main or "_is_admin" in main

bad = []
for f in FILES:
    if f.stem in ("main", "config", "database", "bale_api", "auth"):
        continue
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in t.body:
        if not isinstance(n, ast.FunctionDef):
            continue
        a = [x.arg for x in n.args.args]
        if len(a) < 2 or a[0] != "cid" or a[1] != "uid":
            continue
        d = ast.dump(n)
        if any(k in d for k in ("_guard", "require", "is_admin",
                                "can_section", "has_perm",
                                "_is_admin", "perm.")):
            continue
        if not re.search(r"(INSERT|UPDATE|DELETE)", d, re.I):
            continue
        cbs = route.get((f.stem, n.name), [])
        # اسم‌های آشکارا کاربری
        userish = bool(re.match(
            r'^(user_|my_|show_my|u_|claim|handle_|do_buy|click|'
            r'finish_reg|cancel_reg|restart_reg|start_pay|record_)',
            n.name))
        bad.append((f.stem, n.lineno, n.name, cbs, userish))

print("═══ می‌نویسد · بدون محافظ · از روتر صدا زده می‌شود ═══\n")
susp = [x for x in bad if x[3] and not x[4]]
for x in susp:
    print(f"🔴 {x[0]}.{x[2]}()  خط {x[1]}")
    print(f"    callback: {', '.join(x[3][:3])}")
print(f"\nمشکوک: {len(susp)}")

print("\n═══ کاربری (طبیعی است) ═══")
uok = [x for x in bad if x[4]]
print(f"✅ {len(uok)} تابع کاربری — محافظ لازم ندارند")

print("\n═══ بدون callback (داخلی) ═══")
inner = [x for x in bad if not x[3] and not x[4]]
print(f"ℹ️ {len(inner)} تابع داخلی — از جای دیگر صدا زده می‌شوند")
for x in inner[:8]:
    print(f"    {x[0]}.{x[2]}()")
