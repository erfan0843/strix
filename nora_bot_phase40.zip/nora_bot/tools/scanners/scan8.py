# -*- coding: utf-8 -*-
"""🔍 اسکن ۸ — سناریوی کامل کاربر و ادمین از صفر"""
import os, sys, traceback

os.environ.update(BOT_TOKEN="0:t", SUPER_ADMIN_ID="1",
                  BOT_USERNAME="t", DB_PATH="/tmp/scan8.db")
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/scan8.db" + e)
    except OSError:
        pass
sys.path.insert(0, ".")

import bale_api as b
SENT = []
def _send(cid, text="", kb=None, **k):
    SENT.append({"cid": cid, "text": text, "kb": kb})
    return {"ok": True, "result": {"message_id": len(SENT)}}
b.api = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
b.send = _send
b.send_or_edit = _send
b.send_photo = b.send_document = lambda *a, **k: {"ok": True, "result": {}}
b.get_me = lambda: {"ok": True, "result": {"username": "t"}}

import database, re, pathlib
database.init_db()
main = pathlib.Path("main.py").read_text(encoding="utf-8")
al = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in al.items()}
for ma, fn in re.findall(r"^\s{4}(\w+)\.(init_\w+|seed_\w+)\(\)",
                         main, re.M):
    try:
        getattr(__import__(rev.get(ma, ma)), fn, lambda: None)()
    except Exception:
        pass

import main as M

database.db_execute(
    "INSERT OR IGNORE INTO users (bale_user_id, first_name, last_name,"
    " is_admin, admin_type, profile_status, is_authenticated, mobile)"
    " VALUES (1,'سوپر','ادمین',1,'super_admin','approved',1,"
    "'09120000000')")
database.db_execute(
    "INSERT OR IGNORE INTO users (bale_user_id, first_name, last_name,"
    " profile_status, is_authenticated, mobile, national_id) VALUES "
    "(500,'کاربر','عادی','approved',1,'09121111111','0012345679')")


def cb(uid, data):
    return {"id": "1", "from": {"id": uid}, "message":
            {"chat": {"id": uid}, "message_id": 1}, "data": data}


# ── همهٔ callback های بدون پارامتر را بزن ──
CBS = sorted(set(re.findall(r'data\s*==\s*"([^"]+)"', main)))
crash = []
for c in CBS:
    SENT.clear()
    try:
        M.handle_callback(cb(1, c))
    except Exception as e:
        crash.append(("ادمین", c, f"{type(e).__name__}: {str(e)[:70]}"))

for c in CBS:
    SENT.clear()
    try:
        M.handle_callback(cb(500, c))
    except Exception as e:
        crash.append(("کاربر", c, f"{type(e).__name__}: {str(e)[:70]}"))

print(f"═══ {len(CBS)} دکمهٔ ثابت × ۲ نقش ═══\n")
seen = set()
for who, c, e in crash:
    k = (c, e.split(":")[0])
    if k in seen:
        continue
    seen.add(k)
    print(f"🔴 [{who}] «{c}»  →  {e}")
if not crash:
    print("✅ هیچ استثنایی")
print(f"\nمجموع: {len(seen)} یکتا از {len(crash)}")
