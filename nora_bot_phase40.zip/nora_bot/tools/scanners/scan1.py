# -*- coding: utf-8 -*-
"""🔍 اسکن ۱ — امضای توابع (فقط فراخوانی‌های قطعی)"""
import ast, pathlib

FILES = sorted(pathlib.Path(".").glob("*.py"))
MODS = {f.stem for f in FILES}

# نام‌هایی که با متدهای داخلی پایتون تداخل دارند
BUILTIN_METHODS = {
    "join", "split", "get", "keys", "values", "items", "update",
    "append", "add", "remove", "pop", "close", "read", "write",
    "strip", "replace", "format", "encode", "decode", "count",
    "index", "insert", "sort", "reverse", "copy", "clear", "find",
    "save", "run", "check", "send", "start", "stop", "next", "load",
}

defs = {}
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in t.body:                       # فقط سطح ماژول
        if isinstance(n, ast.FunctionDef):
            a = n.args
            pos = len(a.posonlyargs) + len(a.args)
            defs.setdefault(n.name, []).append({
                "file": f.name, "line": n.lineno,
                "min": pos - len(a.defaults), "max": pos,
                "star": bool(a.vararg), "kwstar": bool(a.kwarg),
                "names": [x.arg for x in a.args],
                "kwonly": {x.arg for x in a.kwonlyargs},
            })

# نگاشت alias ماژول‌ها در هر فایل:  import certgen as cg → cg=certgen
def aliases(tree):
    out = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for al in n.names:
                out[al.asname or al.name] = al.name
    return out

bad = []
for f in FILES:
    src = f.read_text(encoding="utf-8")
    try:
        t = ast.parse(src)
    except SyntaxError:
        continue
    al = aliases(t)
    for n in ast.walk(t):
        if not isinstance(n, ast.Call):
            continue
        fn, name, viamod = n.func, None, None
        if isinstance(fn, ast.Name):
            name = fn.id
        elif isinstance(fn, ast.Attribute) and isinstance(fn.value, ast.Name):
            base = fn.value.id
            if base in al and al[base] in MODS:
                name, viamod = fn.attr, al[base]
            elif base in MODS:
                name, viamod = fn.attr, base
        if not name:
            continue
        if viamod is None and name in BUILTIN_METHODS:
            continue
        cands = defs.get(name)
        if not cands:
            continue
        if viamod:
            cands = [c for c in cands if c["file"] == viamod + ".py"]
        if len(cands) != 1:
            continue
        d = cands[0]
        if any(k.arg is None for k in n.keywords):
            continue
        if any(isinstance(a, ast.Starred) for a in n.args):
            continue
        npos = len(n.args)
        kws = {k.arg for k in n.keywords}
        if npos > d["max"] and not d["star"]:
            bad.append((f.name, n.lineno, name, "زیاد",
                        f"{npos}>{d['max']}", d))
            continue
        unknown = kws - set(d["names"]) - d["kwonly"]
        if unknown and not d["kwstar"]:
            bad.append((f.name, n.lineno, name, "کلید ناشناخته",
                        str(unknown), d))
            continue
        filled = npos + len(kws & (set(d["names"]) | d["kwonly"]))
        if filled < d["min"]:
            bad.append((f.name, n.lineno, name, "کم",
                        f"{filled}<{d['min']}", d))

seen = set()
for b in bad:
    k = (b[0], b[1], b[2])
    if k in seen:
        continue
    seen.add(k)
    print(f"🔴 {b[0]}:{b[1]}  {b[2]}()  {b[3]} ({b[4]})"
          f"   ← تعریف {b[5]['file']}:{b[5]['line']}")
print(f"\nمجموع: {len(seen)}")
