# -*- coding: utf-8 -*-
"""🔍 اسکن ۱۰ — پول: ریال/تومان، گرد کردن، منفی"""
import re, pathlib, ast

FILES = sorted(pathlib.Path(".").glob("*.py"))
print("═══ تبدیل واحد پول ═══")
conv = []
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for i, ln in enumerate(src.split("\n"), 1):
        if ln.strip().startswith("#"):
            continue
        code = ln.split("#")[0]
        # ضرب/تقسیم بر ۱۰ روی مبلغ
        if re.search(r'(amount|price|مبلغ|fee|total|pay)\w*\s*[*/]\s*10\b',
                     code, re.I):
            conv.append((f.name, i, code.strip()[:70]))
for c in conv[:15]:
    print(f"⚠️ {c[0]}:{c[1]}  {c[2]}")
if not conv:
    print("✅ هیچ تبدیل دستی")

print("\n═══ مبلغ منفی محافظت می‌شود؟ ═══")
neg = []
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for i, ln in enumerate(src.split("\n"), 1):
        code = ln.split("#")[0]
        if re.search(r'total_points\s*=\s*COALESCE\([^)]*\)\s*[-]', code):
            if "max(" not in code:
                neg.append((f.name, i, code.strip()[:70]))
for n in neg[:10]:
    print(f"⚠️ {n[0]}:{n[1]}  {n[2]}")
if not neg:
    print("✅ کسر امتیاز محافظت‌شده یا نبود")

print("\n═══ int() بدون try روی ورودی کاربر ═══")
risky = []
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
        src = f.read_text(encoding="utf-8").split("\n")
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not (isinstance(n, ast.Call) and
                isinstance(n.func, ast.Name) and n.func.id == "int"):
            continue
        if not n.args:
            continue
        a = n.args[0]
        # int(txt) یا int(raw) — ورودی مستقیم کاربر
        if isinstance(a, ast.Name) and a.id in ("txt", "text", "raw",
                                                 "val", "value"):
            ln = src[n.lineno - 1] if n.lineno <= len(src) else ""
            risky.append((f.name, n.lineno, ln.strip()[:65]))
seen = set()
for r in risky:
    if (r[0], r[1]) in seen:
        continue
    seen.add((r[0], r[1]))
    print(f"⚠️ {r[0]}:{r[1]}  {r[2]}")
print(f"مجموع: {len(seen)}")
