# -*- coding: utf-8 -*-
"""🔍 اسکن ۴ — state های بی‌هندلر"""
import re, pathlib

FILES = sorted(pathlib.Path(".").glob("*.py"))
main = pathlib.Path("main.py").read_text(encoding="utf-8")

# set_state(uid, "xxx"  یا  set_state(uid, STATE_X
made = {}
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for m in re.finditer(r'set_state\(\s*\w+\s*,\s*"([^"]+)"', src):
        made.setdefault(m.group(1), set()).add(f.name)
    for m in re.finditer(r'set_state\(\s*\w+\s*,\s*(STATE_\w+)', src):
        # مقدار ثابت را پیدا کن
        cn = m.group(1)
        mv = re.search(rf'^{cn}\s*=\s*"([^"]+)"', src, re.M)
        if mv:
            made.setdefault(mv.group(1), set()).add(f.name)
        else:
            for f2 in FILES:
                s2 = f2.read_text(encoding="utf-8")
                mv2 = re.search(rf'^{cn}\s*=\s*"([^"]+)"', s2, re.M)
                if mv2:
                    made.setdefault(mv2.group(1), set()).add(f.name)
                    break

# هندلرها: در main یا داخل ماژول‌ها
allsrc = "\n".join(f.read_text(encoding="utf-8") for f in FILES)

orphan = []
for st, where in sorted(made.items()):
    pats = [f'"{st}"', f"'{st}'"]
    # آیا جایی مقایسه می‌شود؟
    used = False
    for p in pats:
        for m in re.finditer(re.escape(p), allsrc):
            ctx = allsrc[max(0, m.start()-60):m.start()]
            if any(k in ctx for k in ("==", "startswith", " in (",
                                      "in [", "!=", "state_name",
                                      "st ==", "st.startswith")):
                used = True
                break
        if used:
            break
    # یا با پیشوند در main هندل می‌شود
    if not used:
        for m in re.finditer(r'state_name\.startswith\("([^"]+)"\)',
                             main):
            if st.startswith(m.group(1)):
                used = True
                break
    if not used:
        orphan.append((st, ",".join(sorted(where))))

print("═══ state بدون هندلر ═══")
for s, w in orphan:
    print(f"🔴 «{s}»   ({w})")
if not orphan:
    print("✅ هیچ")
print(f"\nمجموع state: {len(made)}")
