# -*- coding: utf-8 -*-
"""🔬 عمیق ۵ — منطق: شرط همیشه‌درست، مقایسهٔ خطرناک، ==None"""
import ast, re, pathlib

FILES = sorted(pathlib.Path(".").glob("*.py"))

print("═══ مقایسهٔ عدد با رشته (همیشه False) ═══")
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
        src = f.read_text(encoding="utf-8").split("\n")
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not isinstance(n, ast.Compare):
            continue
        for op, cmp_ in zip(n.ops, n.comparators):
            if not isinstance(op, (ast.Eq, ast.NotEq)):
                continue
            L, R = n.left, cmp_
            # int == "str"
            if (isinstance(L, ast.Constant) and isinstance(L.value, int)
                    and isinstance(R, ast.Constant)
                    and isinstance(R.value, str)) or \
               (isinstance(R, ast.Constant) and isinstance(R.value, int)
                    and isinstance(L, ast.Constant)
                    and isinstance(L.value, str)):
                ln = src[n.lineno-1].strip() if n.lineno <= len(src) else ""
                print(f"🔴 {f.name}:{n.lineno}  {ln[:60]}")

print("\n═══ `is` با رشته/عدد (رفتار غیرقابل‌اتکا) ═══")
cnt = 0
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
        src = f.read_text(encoding="utf-8").split("\n")
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not isinstance(n, ast.Compare):
            continue
        for op, c in zip(n.ops, n.comparators):
            if isinstance(op, (ast.Is, ast.IsNot)) and \
                    isinstance(c, ast.Constant) and \
                    isinstance(c.value, (str, int)) and \
                    c.value is not True and c.value is not False:
                ln = src[n.lineno-1].strip() if n.lineno <= len(src) else ""
                print(f"🔴 {f.name}:{n.lineno}  {ln[:60]}")
                cnt += 1
if not cnt:
    print("✅ هیچ")

print("\n═══ except بدون log (باگ پنهان‌کن) در توابع کلیدی ═══")
KEY = ("issue", "publish", "build", "pay", "save", "submit",
       "approve", "award", "point")
silent = []
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for fn in ast.walk(t):
        if not isinstance(fn, ast.FunctionDef):
            continue
        if not any(k in fn.name.lower() for k in KEY):
            continue
        for h in ast.walk(fn):
            if not isinstance(h, ast.ExceptHandler):
                continue
            body = ast.dump(h)
            if "log" in body or "send" in body or "print" in body:
                continue
            if len(h.body) == 1 and isinstance(h.body[0], ast.Pass):
                silent.append((f.name, h.lineno, fn.name))
for s in silent[:20]:
    print(f"⚠️ {s[0]}:{s[1]}  در {s[2]}()")
print(f"مجموع: {len(silent)}")

print("\n═══ dict.get با پیش‌فرض غلط ═══")
# .get("x", 0) بعد روی رشته عمل شود یا برعکس
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for i, ln in enumerate(src.split("\n"), 1):
        m = re.search(r'\.get\("(\w+)",\s*0\)\s*\.(strip|lower|split)',
                      ln)
        if m:
            print(f"🔴 {f.name}:{i}  {ln.strip()[:60]}")
