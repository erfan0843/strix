# -*- coding: utf-8 -*-
"""🔬 عمیق ۲ — نشتی منابع: فایل، اتصال، حافظه"""
import ast, re, pathlib

FILES = sorted(pathlib.Path(".").glob("*.py"))

print("═══ open() بدون with (نشتی فایل) ═══")
leak = []
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
        src = f.read_text(encoding="utf-8").split("\n")
    except SyntaxError:
        continue
    withs = set()
    for n in ast.walk(t):
        if isinstance(n, (ast.With, ast.AsyncWith)):
            for item in n.items:
                if isinstance(item.context_expr, ast.Call):
                    withs.add(id(item.context_expr))
    for n in ast.walk(t):
        if not (isinstance(n, ast.Call) and
                isinstance(n.func, ast.Name) and n.func.id == "open"):
            continue
        if id(n) in withs:
            continue
        ln = src[n.lineno - 1].strip() if n.lineno <= len(src) else ""
        # .read() / .write() زنجیره‌ای امن است
        if re.search(r'open\([^)]*\)\.(read|write)', ln):
            continue
        leak.append((f.name, n.lineno, ln[:65]))
for x in leak[:15]:
    print(f"⚠️ {x[0]}:{x[1]}  {x[2]}")
if not leak:
    print("✅ هیچ")

print("\n═══ sqlite connect بدون close ═══")
for f in FILES:
    src = f.read_text(encoding="utf-8")
    if "sqlite3.connect" in src:
        n_open = src.count("sqlite3.connect")
        n_close = src.count(".close()")
        print(f"{'⚠️' if n_open > n_close else '✅'} {f.name}: "
              f"{n_open} connect / {n_close} close")

print("\n═══ حلقهٔ بی‌پایان بالقوه ═══")
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if isinstance(n, ast.While) and \
                isinstance(n.test, ast.Constant) and n.test.value is True:
            has_break = any(isinstance(x, ast.Break)
                            for x in ast.walk(n))
            if not has_break:
                print(f"🔴 {f.name}:{n.lineno}  while True بدون break")

print("\n═══ کش بدون سقف (رشد حافظه) ═══")
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for m in re.finditer(r'^(_\w*[Cc]ache\w*)\s*=\s*\{\}', src, re.M):
        nm = m.group(1)
        ln = src[:m.start()].count("\n") + 1
        # آیا جایی پاک می‌شود؟
        cleared = bool(re.search(rf'{nm}\.(clear|pop)\(', src))
        cap = bool(re.search(rf'len\({nm}\)\s*>', src))
        flag = "✅" if (cleared or cap) else "⚠️"
        print(f"{flag} {f.name}:{ln}  {nm}  "
              f"{'پاک‌شدنی' if cleared else ''}"
              f"{' سقف‌دار' if cap else ''}"
              f"{'بدون مدیریت' if not (cleared or cap) else ''}")
