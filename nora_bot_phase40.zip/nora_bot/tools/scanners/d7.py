# -*- coding: utf-8 -*-
"""🔬 عمیق ۷ — کارایی: N+1 query، حلقهٔ سنگین"""
import ast, re, pathlib

FILES = sorted(pathlib.Path(".").glob("*.py"))

print("═══ کوئری داخل حلقه (N+1) ═══")
n1 = []
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
        src = f.read_text(encoding="utf-8").split("\n")
    except SyntaxError:
        continue
    for loop in ast.walk(t):
        if not isinstance(loop, (ast.For, ast.While)):
            continue
        # کوئری‌های داخل بدنه
        qs = []
        for n in ast.walk(loop):
            if not isinstance(n, ast.Call):
                continue
            fn = getattr(n.func, "attr", None) or \
                getattr(n.func, "id", None)
            if fn in ("db_execute", "db_scalar", "_dx"):
                qs.append(n.lineno)
        if len(qs) >= 2:
            ln = src[loop.lineno-1].strip() if loop.lineno <= len(src) \
                else ""
            n1.append((f.name, loop.lineno, len(qs), ln[:50]))
n1.sort(key=lambda x: -x[2])
for x in n1[:15]:
    print(f"⚡ {x[0]}:{x[1]}  {x[2]} کوئری در حلقه  | {x[3]}")
print(f"مجموع: {len(n1)}")

print("\n═══ ارسال پیام داخل حلقه بدون تأخیر ═══")
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for loop in ast.walk(t):
        if not isinstance(loop, (ast.For, ast.While)):
            continue
        sends, sleeps = 0, 0
        for n in ast.walk(loop):
            if isinstance(n, ast.Call):
                fn = getattr(n.func, "attr", None) or \
                    getattr(n.func, "id", None)
                if fn in ("send", "send_photo", "send_document",
                          "send_or_edit"):
                    sends += 1
                if fn == "sleep":
                    sleeps += 1
        if sends and not sleeps:
            print(f"⚡ {f.name}:{loop.lineno}  {sends} ارسال "
                  f"بدون sleep")

print("\n═══ خواندن فایل داخل حلقه ═══")
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for loop in ast.walk(t):
        if not isinstance(loop, (ast.For, ast.While)):
            continue
        for n in ast.walk(loop):
            if isinstance(n, ast.Call) and \
                    isinstance(n.func, ast.Attribute) and \
                    n.func.attr in ("read_text", "read_bytes"):
                print(f"⚡ {f.name}:{n.lineno}  خواندن فایل در حلقه")
