# -*- coding: utf-8 -*-
"""🔍 اسکن ۹ — دکمه‌های پارامتری با شناسهٔ ناموجود/خراب"""
import os, sys, re, pathlib

os.environ.update(BOT_TOKEN="0:t", SUPER_ADMIN_ID="1",
                  BOT_USERNAME="t", DB_PATH="/tmp/scan9.db")
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/scan9.db" + e)
    except OSError:
        pass
sys.path.insert(0, ".")
import bale_api as b
b.api = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
b.send = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
b.send_or_edit = b.send
b.send_photo = b.send_document = b.send
b.get_me = lambda: {"ok": True, "result": {"username": "t"}}

import database
database.init_db()
main = pathlib.Path("main.py").read_text(encoding="utf-8")
al = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in al.items()}
for ma, fn in re.findall(r"^\s{4}(\w+)\.(init_\w+|seed_\w+)\(\)",
                         main, re.M):
    try:
        getattr(__import__(rev.get(ma, ma)), fn, lambda: None)()
    except Exception:
        pass
import main as M

database.db_execute(
    "INSERT OR IGNORE INTO users (bale_user_id, first_name, is_admin,"
    " admin_type, profile_status, is_authenticated) VALUES "
    "(1,'ادمین',1,'super_admin','approved',1)")


def cb(uid, data):
    return {"id": "1", "from": {"id": uid}, "message":
            {"chat": {"id": uid}, "message_id": 1}, "data": data}


PREF = sorted(set(re.findall(r'data\.startswith\("([^"]+)"\)', main)))
SUF = ["999999", "0", "-1", "abc", "999999_999999", "", "1_abc"]
crash = []
n = 0
for p in PREF:
    for s in SUF:
        n += 1
        try:
            M.handle_callback(cb(1, p + s))
        except Exception as e:
            crash.append((p + s, f"{type(e).__name__}: {str(e)[:70]}"))

print(f"═══ {len(PREF)} پیشوند × {len(SUF)} ورودی = {n} ═══\n")
seen = set()
for c, e in crash:
    k = (c.split("_")[0], e.split(":")[0])
    if k in seen:
        continue
    seen.add(k)
    print(f"🔴 «{c}»  →  {e}")
if not crash:
    print("✅ هیچ استثنایی")
print(f"\nیکتا: {len(seen)}  ·  کل: {len(crash)}")
