# -*- coding: utf-8 -*-
"""🔬 عمیق ۳ — امنیت: تزریق SQL، دسترسی، افشای داده"""
import ast, re, pathlib

FILES = sorted(pathlib.Path(".").glob("*.py"))

print("═══ SQL با f-string یا + (خطر تزریق) ═══")
inj = []
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
        src = f.read_text(encoding="utf-8").split("\n")
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not isinstance(n, ast.Call):
            continue
        fn = getattr(n.func, "attr", None) or getattr(n.func, "id", None)
        if fn not in ("db_execute", "db_scalar", "_dx", "_dbx",
                      "execute", "executemany"):
            continue
        if not n.args:
            continue
        a0 = n.args[0]
        risky = False
        vals = []
        if isinstance(a0, ast.JoinedStr):
            for v in a0.values:
                if isinstance(v, ast.FormattedValue):
                    risky = True
                    if isinstance(v.value, ast.Name):
                        vals.append(v.value.id)
                    elif isinstance(v.value, ast.Attribute):
                        vals.append(v.value.attr)
                    else:
                        vals.append("expr")
        if risky:
            ln = src[n.lineno - 1].strip() if n.lineno <= len(src) else ""
            inj.append((f.name, n.lineno, vals, ln[:60]))
for x in inj[:20]:
    print(f"⚠️ {x[0]}:{x[1]}  متغیر={x[2]}  | {x[3]}")
print(f"مجموع: {len(inj)}")

print("\n═══ تابع ادمین بدون _guard/require ═══")
noguard = []
for f in FILES:
    if f.stem in ("main", "config", "database", "bale_api", "auth"):
        continue
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in t.body:
        if not isinstance(n, ast.FunctionDef):
            continue
        args = [a.arg for a in n.args.args]
        if len(args) < 2 or args[0] != "cid" or args[1] != "uid":
            continue
        body = ast.dump(n)
        # نشانهٔ بررسی دسترسی
        if any(k in body for k in ("_guard", "require", "is_admin",
                                   "can_section", "has_perm",
                                   "_is_admin")):
            continue
        # تابع کاربری؟ نامش با user/my/show_my شروع می‌شود
        if re.match(r'^(user_|my_|show_my|u_|claim|handle_)', n.name):
            continue
        # آیا چیزی می‌نویسد؟
        writes = bool(re.search(
            r"(INSERT|UPDATE|DELETE)", ast.dump(n), re.I))
        noguard.append((f.name, n.lineno, n.name, writes))
w = [x for x in noguard if x[3]]
print(f"بدون محافظ ولی **می‌نویسد** ({len(w)}):")
for x in w[:15]:
    print(f"🔴 {x[0]}:{x[1]}  {x[2]}()")
print(f"\nبدون محافظ فقط خواندنی: {len(noguard) - len(w)}")

print("\n═══ افشای اطلاعات حساس در لاگ ═══")
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for i, ln in enumerate(src.split("\n"), 1):
        if re.search(r'log\([^)]*(TOKEN|token|password|api_key|'
                     r'API_KEY|secret)', ln) and "***" not in ln:
            print(f"⚠️ {f.name}:{i}  {ln.strip()[:65]}")
