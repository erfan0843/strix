# -*- coding: utf-8 -*-
"""🔬 عمیق ۱ — محدودیت‌های پروتکل بله"""
import ast, re, pathlib

FILES = sorted(pathlib.Path(".").glob("*.py"))

# ── ۱) callback_data بیش از ۶۴ بایت ──
print("═══ callback_data طولانی (سقف ۶۴ بایت) ═══")
long_cb = []
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for i, ln in enumerate(src.split("\n"), 1):
        for m in re.finditer(r'"callback_data":\s*f?"([^"]*)"', ln):
            v = m.group(1)
            # f-string با {} → تخمین: هر {} حدود ۱۰ کاراکتر
            est = len(re.sub(r'\{[^}]*\}', 'X' * 12, v).encode())
            if est > 64:
                long_cb.append((f.name, i, v[:50], est))
for x in long_cb[:15]:
    print(f"🔴 {x[0]}:{x[1]}  ~{x[3]} بایت  «{x[2]}»")
if not long_cb:
    print("✅ هیچ")

# ── ۲) متن دکمه بیش از ~۶۴ کاراکتر ──
print("\n═══ متن دکمهٔ خیلی بلند ═══")
long_txt = []
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for i, ln in enumerate(src.split("\n"), 1):
        for m in re.finditer(r'"text":\s*"([^"]{45,})"', ln):
            v = m.group(1)
            if "[:" in ln:          # برش دارد
                continue
            long_txt.append((f.name, i, len(v), v[:40]))
for x in long_txt[:12]:
    print(f"⚠️ {x[0]}:{x[1]}  {x[2]} نویسه  «{x[3]}…»")
if not long_txt:
    print("✅ هیچ")

# ── ۳) بیش از ۱۰ ردیف دکمه (قانون کاربر) ──
print("\n═══ کیبورد با بیش از ۱۰ ردیف (ثابت) ═══")
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not isinstance(n, ast.Dict):
            continue
        for k, v in zip(n.keys, n.values):
            if not (isinstance(k, ast.Constant) and
                    k.value == "inline_keyboard"):
                continue
            if isinstance(v, ast.List) and len(v.elts) > 10:
                print(f"🔴 {f.name}:{n.lineno}  "
                      f"{len(v.elts)} ردیف ثابت")
print("(ردیف‌های پویا با append در audit.py بررسی می‌شوند)")
