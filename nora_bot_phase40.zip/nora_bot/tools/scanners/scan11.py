# -*- coding: utf-8 -*-
"""🔍 اسکن ۱۱ — کد مرده، تکرار، سنگینی"""
import ast, re, pathlib, collections

FILES = sorted(pathlib.Path(".").glob("*.py"))
TESTS = "\n".join(f.read_text(encoding="utf-8")
                  for f in pathlib.Path("tests").glob("*.py"))
TOOLS = "\n".join(f.read_text(encoding="utf-8")
                  for f in pathlib.Path("tools").glob("*.py"))
ALL = "\n".join(f.read_text(encoding="utf-8") for f in FILES)
ALL2 = ALL + TESTS + TOOLS

# ── توابع سطح ماژول که هیچ‌جا صدا زده نمی‌شوند ──
print("═══ توابع بی‌استفاده (کاندید حذف) ═══")
dead = []
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in t.body:
        if not isinstance(n, ast.FunctionDef):
            continue
        nm = n.name
        if nm.startswith("__"):
            continue
        # چند بار در کل پروژه ظاهر می‌شود؟
        cnt = len(re.findall(rf'\b{re.escape(nm)}\b', ALL2))
        if cnt <= 1:            # فقط خود تعریف
            dead.append((f.name, n.lineno, nm,
                         n.end_lineno - n.lineno + 1))
dead.sort(key=lambda x: -x[3])
for d in dead[:20]:
    print(f"🧹 {d[0]}:{d[1]}  {d[2]}()  ({d[3]} خط)")
print(f"مجموع: {len(dead)} تابع · "
      f"{sum(d[3] for d in dead)} خط")

# ── ثابت‌های بی‌استفاده ──
print("\n═══ ثابت‌های بی‌استفاده ═══")
dc = []
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in t.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and \
                isinstance(n.targets[0], ast.Name):
            nm = n.targets[0].id
            if not nm.isupper() or len(nm) < 3:
                continue
            cnt = len(re.findall(rf'\b{re.escape(nm)}\b', ALL2))
            if cnt <= 1:
                dc.append((f.name, n.lineno, nm))
for d in dc[:15]:
    print(f"🧹 {d[0]}:{d[1]}  {d[2]}")
print(f"مجموع: {len(dc)}")

# ── import های تکراری داخل تابع ──
print("\n═══ import تکراری داخل توابع (کندی) ═══")
rep = collections.Counter()
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for m in re.finditer(r'^\s+from (\w+) import', src, re.M):
        rep[(f.name, m.group(1))] += 1
top = [(k, v) for k, v in rep.items() if v >= 8]
top.sort(key=lambda x: -x[1])
for (f, m), v in top[:15]:
    print(f"⚡ {f}: «from {m} import» {v} بار تکرار شده")
print(f"مجموع نقاط: {len(top)}")
