# -*- coding: utf-8 -*-
"""🔬 عمیق ۸ — تکرار کد، ثابت جادویی، ناسازگاری سبک"""
import ast, re, pathlib, hashlib, collections

FILES = sorted(pathlib.Path(".").glob("*.py"))

print("═══ توابع کاملاً یکسان (کد تکراری) ═══")
sigs = collections.defaultdict(list)
for f in FILES:
    try:
        src = f.read_text(encoding="utf-8")
        t = ast.parse(src)
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if not isinstance(n, ast.FunctionDef):
            continue
        body = ast.dump(ast.Module(body=n.body, type_ignores=[]))
        if len(body) < 300:      # خیلی کوچک → بی‌اهمیت
            continue
        h = hashlib.md5(body.encode()).hexdigest()
        sigs[h].append((f.name, n.lineno, n.name,
                        n.end_lineno - n.lineno + 1))
dups = [v for v in sigs.values() if len(v) > 1]
for grp in sorted(dups, key=lambda g: -g[0][3])[:10]:
    print(f"🧹 {grp[0][3]} خط ×{len(grp)}: " +
          " · ".join(f"{x[0]}:{x[2]}" for x in grp))
print(f"مجموع گروه: {len(dups)}  ·  "
      f"خط قابل صرفه‌جویی: "
      f"{sum(g[0][3]*(len(g)-1) for g in dups)}")

print("\n═══ الگوی تکراری _guard در ماژول‌ها ═══")
g = 0
for f in FILES:
    src = f.read_text(encoding="utf-8")
    if re.search(r'^def _guard\(cid, uid\)', src, re.M):
        g += 1
print(f"🧹 {g} ماژول هرکدام _guard جدا دارند "
      f"(می‌شود یکی مشترک شد)")

print("\n═══ f-string بدون placeholder ═══")
c = 0
for f in FILES:
    try:
        t = ast.parse(f.read_text(encoding="utf-8"))
    except SyntaxError:
        continue
    for n in ast.walk(t):
        if isinstance(n, ast.JoinedStr) and \
                not any(isinstance(v, ast.FormattedValue)
                        for v in n.values):
            c += 1
print(f"🧹 {c} مورد (فقط `f` اضافی — بی‌خطر)")

print("\n═══ str.format یا % به‌جای f-string ═══")
old = 0
for f in FILES:
    src = f.read_text(encoding="utf-8")
    old += len(re.findall(r'"\s*%\s*\(', src))
    old += len(re.findall(r'\.format\(', src))
print(f"ℹ️ {old} مورد سبک قدیمی")

print("\n═══ خط بیش از ۹۹ نویسه ═══")
long_lines = collections.Counter()
for f in FILES:
    for ln in f.read_text(encoding="utf-8").split("\n"):
        if len(ln) > 99:
            long_lines[f.name] += 1
for k, v in long_lines.most_common(8):
    print(f"ℹ️ {k}: {v} خط بلند")
print(f"مجموع: {sum(long_lines.values())}")
