# -*- coding: utf-8 -*-
"""🔍 اسکن ۳ — روتر: callback بی‌هندلر، تداخل پیشوند، state یتیم"""
import ast, re, pathlib

main = pathlib.Path("main.py").read_text(encoding="utf-8")
FILES = sorted(pathlib.Path(".").glob("*.py"))

# ── همهٔ callback_data های تولیدشده ──
made = set()
for f in FILES:
    src = f.read_text(encoding="utf-8")
    for m in re.finditer(r'"callback_data":\s*f?"([^"{}]*)', src):
        v = m.group(1).strip()
        if v:
            made.add((v, f.name))
    for m in re.finditer(r'"callback_data":\s*f"([^"]*)"', src):
        v = m.group(1)
        if "{" in v:
            made.add((v.split("{")[0], f.name))

# ── همهٔ الگوهای روتر ──
exact = set(re.findall(r'data\s*==\s*"([^"]+)"', main))
exact |= set(re.findall(r"data\s+in\s+\(([^)]*)\)", main) and
             [x.strip().strip('"\'')
              for grp in re.findall(r"data\s+in\s+\(([^)]*)\)", main)
              for x in grp.split(",") if x.strip()])
pref = set(re.findall(r'data\.startswith\("([^"]+)"\)', main))

def routed(cb):
    if cb in exact:
        return True
    for p in pref:
        if cb.startswith(p):
            return True
    return False

orphan = sorted({(c, f) for c, f in made
                 if c and not routed(c) and c != "noop"})
print("═══ callback بدون هندلر ═══")
for c, f in orphan[:25]:
    print(f"🔴 «{c}»   ({f})")
if not orphan:
    print("✅ هیچ")

# ── تداخل پیشوند: کوتاه‌تر قبل از بلندتر ──
print("\n═══ تداخل ترتیب پیشوندها ═══")
pos = {}
for p in pref:
    i = main.find(f'data.startswith("{p}")')
    if i >= 0:
        pos[p] = i
bad = []
for a in pref:
    for b in pref:
        if a != b and b.startswith(a) and pos.get(a, 0) < pos.get(b, 0):
            bad.append((a, b))
for a, b in sorted(set(bad))[:20]:
    print(f"🔴 «{a}» (خط زودتر) «{b}» را می‌بلعد")
if not bad:
    print("✅ هیچ")
