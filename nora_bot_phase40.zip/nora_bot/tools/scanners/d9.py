# -*- coding: utf-8 -*-
"""🔬 عمیق ۹ — پایداری: تکرار پیام، race، بازیابی"""
import os, sys, pathlib, re, time

os.environ.update(BOT_TOKEN="0:t", SUPER_ADMIN_ID="1",
                  BOT_USERNAME="t", DB_PATH="/tmp/d9.db")
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/d9.db" + e)
    except OSError:
        pass
sys.path.insert(0, ".")
import bale_api as b
SENT = []
b.api = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
b.send = lambda cid, t="", kb=None, **k: (
    SENT.append(str(t)), {"ok": True, "result": {"message_id": 1}})[1]
b.send_or_edit = b.send
b.send_photo = b.send_document = lambda *a, **k: {"ok": True,
                                                  "result": {}}
import database
database.init_db()
main = pathlib.Path("main.py").read_text(encoding="utf-8")
al = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in al.items()}
for ma, fn in re.findall(r"^\s{4}(\w+)\.(init_\w+|seed_\w+)\(\)",
                         main, re.M):
    try:
        getattr(__import__(rev.get(ma, ma)), fn, lambda: None)()
    except Exception:
        pass

OK, BAD = [], []
def T(n, c, e=""):
    (OK if c else BAD).append((n, e))

database.db_execute(
    "INSERT INTO users (bale_user_id,first_name,national_id,mobile,"
    "profile_status,is_authenticated,is_admin,admin_type) VALUES "
    "(1,'س','0012345679','09120000000','approved',1,1,'super_admin')")
database.db_execute(
    "INSERT INTO users (bale_user_id,first_name,national_id,"
    "profile_status,is_authenticated) VALUES "
    "(600,'ک','0023456787','approved',1)")

import certcenter as cc, certissue as ci, events as ev
import attendance as att

import docx
d = docx.Document()
d.add_paragraph("{نام} {رویداد}")
d.save("/tmp/d9.docx")
tid = database.db_execute(
    "INSERT INTO cert_templates (name,file_path,kind,is_active,"
    "is_default) VALUES ('t','/tmp/d9.docx','docx',1,1)")

eid = database.db_execute(
    "INSERT INTO events (title,event_type,status,start_date,"
    "has_certificate) VALUES ('ر','workshop','published',"
    "'1405/05/01',1)")
database.db_execute(
    "INSERT INTO event_registrations (event_id,bale_user_id,status)"
    " VALUES (?,?,'confirmed')", (eid, 600))

# ══ ۱) صدور دوباره تکراری نمی‌سازد ══
c1, _ = ci.issue_one(eid, 600, 1, send_to_user=False)
n1 = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
c2, _ = ci.issue_one(eid, 600, 1, send_to_user=False)
n2 = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
T("صدور دوباره رکورد تازه نمی‌سازد", n1 == n2, f"{n1}→{n2}")

# ══ ۲) دو بار build_one پشت سر هم ══
iid = cc.create_issue(1, "p", tid)
cc.scan_template(tid)
for k in cc.template_fields(tid)[0]:
    if cc.field_kind(k) != "system":
        cc.set_value(iid, k, "x")
cc.fill_from_event(iid, eid)
cc.publish(iid, notify=False)
sh = cc.shares(iid)[0]
a1, _ = cc.build_one(iid, sh["id"], notify=False)
nb = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
a2, _ = cc.build_one(iid, sh["id"], notify=False)
na = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
T("build_one دوبار → یک رکورد", nb == na, f"{nb}→{na}")
T("همان رکورد برمی‌گردد",
  bool(a1) and bool(a2) and a1["id"] == a2["id"])

# ══ ۳) publish دوبار اعلان تکراری نمی‌فرستد ══
SENT.clear()
cc.publish(iid, notify=True)
k1 = len(SENT)
SENT.clear()
cc.publish(iid, notify=True)
k2 = len(SENT)
T("اعلان دوباره فرستاده نمی‌شود", k2 == 0, f"{k1}→{k2}")

# ══ ۴) شمارندهٔ کاربر دوبار زیاد نمی‌شود ══
u = database.db_execute("SELECT total_certificates FROM users "
                        "WHERE bale_user_id=600", fetch="one")
real = database.db_scalar(
    "SELECT COUNT(*) FROM certificates WHERE bale_user_id=600") or 0
T("شمارنده با واقعیت می‌خواند",
  (u or {}).get("total_certificates", 0) == real,
  f"کش={u.get('total_certificates')} واقعی={real}")

# ══ ۵) کد فردی در فشار — ۲۰۰ تا ══
import certverify as cv
codes = {cv.new_person_code() for _ in range(200)}
T("۲۰۰ کد فردی همه یکتا", len(codes) == 200, f"{len(codes)}")

# ══ ۶) بازیابی: فایل پاک شود ══
if a1:
    for col in ("png_path", "pdf_path", "docx_path"):
        p = a1.get(col)
        if p and os.path.exists(p):
            os.remove(p)
    import certgen as cg
    r = cg.regenerate(a1)
    T("بازتولید بعد از پاک‌شدن فایل", bool(r), str(r)[:40])
    fresh = database.db_execute(
        "SELECT * FROM certificates WHERE id=?", (a1["id"],),
        fetch="one")
    T("کد فردی بعد بازتولید نمی‌پرد",
      fresh.get("person_code") == a1.get("person_code"))

# ══ ۷) state گیر نمی‌کند ══
from auth import set_state, get_state_name, clear_state
set_state(600, "cc_title", {}, merge=False)
cc.handle_text({"from": {"id": 600}, "chat": {"id": 600},
                "text": "انصراف"})
T("انصراف state را آزاد می‌کند", not get_state_name(600),
  str(get_state_name(600)))

print("═══ پایداری ═══\n")
for n, e in OK:
    print(f"  ✅ {n}")
for n, e in BAD:
    print(f"  🔴 {n}  {e}")
print(f"\n{len(OK)} موفق · {len(BAD)} ناموفق")
