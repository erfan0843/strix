# -*- coding: utf-8 -*-
"""🔬 عمیق ۶ — سناریوهای مرزی واقعی"""
import os, sys, pathlib, re

os.environ.update(BOT_TOKEN="0:t", SUPER_ADMIN_ID="1",
                  BOT_USERNAME="t", DB_PATH="/tmp/d6.db")
for e in ("", "-wal", "-shm"):
    try:
        os.remove("/tmp/d6.db" + e)
    except OSError:
        pass
sys.path.insert(0, ".")
import bale_api as b
SENT = []
b.api = lambda *a, **k: {"ok": True, "result": {"message_id": 1}}
b.send = lambda cid, t="", kb=None, **k: (
    SENT.append(str(t)), {"ok": True, "result": {"message_id": 1}})[1]
b.send_or_edit = b.send
b.send_photo = b.send_document = lambda *a, **k: {"ok": True,
                                                  "result": {}}
import database
database.init_db()
main = pathlib.Path("main.py").read_text(encoding="utf-8")
al = dict(re.findall(r"^import (\w+) as (\w+)$", main, re.M))
rev = {v: k for k, v in al.items()}
for ma, fn in re.findall(r"^\s{4}(\w+)\.(init_\w+|seed_\w+)\(\)",
                         main, re.M):
    try:
        getattr(__import__(rev.get(ma, ma)), fn, lambda: None)()
    except Exception:
        pass

OK, BAD = [], []
def T(n, c, e=""):
    (OK if c else BAD).append((n, e))

database.db_execute(
    "INSERT INTO users (bale_user_id, first_name, last_name,"
    " national_id, mobile, profile_status, is_authenticated,"
    " is_admin, admin_type) VALUES (1,'س','ا','0012345679',"
    "'09120000000','approved',1,1,'super_admin')")

import certcenter as cc, certissue as ci, certverify as cv
import certgen as cg, events as ev, attendance as att, jalali as J

# ══ ۱) گواهینامه بدون هیچ کاربر ══
import docx
d = docx.Document()
d.add_paragraph("{نام} {کدملی} {رویداد}")
d.save("/tmp/d6.docx")
tid = database.db_execute(
    "INSERT INTO cert_templates (name,file_path,kind,is_active,"
    "is_default) VALUES ('t','/tmp/d6.docx','docx',1,1)")

iid = cc.create_issue(1, "بدون گیرنده", tid)
cc.scan_template(tid)
for k in cc.template_fields(tid)[0]:
    if cc.field_kind(k) != "system":
        cc.set_value(iid, k, "x")
n, err = cc.publish(iid, notify=False)
T("انتشار بدون گیرنده جلو گرفته شد", bool(err), f"err={err!r}")

# ══ ۲) گیرندهٔ بدون حساب ربات ══
cc.fill_from_rows(iid, [{"full_name": "غریبه", "national_id": "",
                         "mobile": "", "extra": {}}])
n2, err2 = cc.publish(iid, notify=True)
T("گیرندهٔ بی‌حساب اعلان نمی‌گیرد", n2 == 0, f"n={n2}")
sh = cc.shares(iid)[0]
c1, e1 = cc.build_one(iid, sh["id"], notify=False)
T("گواهینامه برای بی‌حساب ساخته می‌شود", bool(c1), str(e1)[:50])
if c1:
    T("بدون bale_user_id ثبت شد", c1.get("bale_user_id") is None)

# ══ ۳) دو طرح، یک نفر ══
iid2 = cc.create_issue(1, "طرح دوم", tid)
for k in cc.template_fields(tid)[0]:
    if cc.field_kind(k) != "system":
        cc.set_value(iid2, k, "y")
database.db_execute(
    "INSERT INTO users (bale_user_id,first_name,national_id,"
    "profile_status) VALUES (800,'دو','0023456787','approved')")
cc.add_share(iid, 800, "دو", "0023456787", "")
cc.add_share(iid2, 800, "دو", "0023456787", "")
cc.publish(iid2, notify=False)
s1 = [x for x in cc.shares(iid) if x.get("bale_user_id") == 800][0]
s2 = [x for x in cc.shares(iid2) if x.get("bale_user_id") == 800][0]
ca, _ = cc.build_one(iid, s1["id"], notify=False)
cb_, _ = cc.build_one(iid2, s2["id"], notify=False)
T("یک نفر از دو طرح دو گواهینامه می‌گیرد",
  bool(ca) and bool(cb_) and ca["id"] != cb_["id"])
if ca and cb_:
    T("کد فردی‌شان متفاوت است",
      ca.get("person_code") != cb_.get("person_code"))

# ══ ۴) حذف طرح، گواهینامه می‌ماند ══
nb = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
database.db_execute("DELETE FROM cert_shares WHERE issue_id=?",
                    (iid2,))
database.db_execute("DELETE FROM cert_issues WHERE id=?", (iid2,))
na = database.db_scalar("SELECT COUNT(*) FROM certificates") or 0
T("حذف طرح گواهینامه را پاک نمی‌کند", nb == na, f"{nb}→{na}")

# ══ ۵) استعلام گواهینامهٔ باطل‌شده ══
if ca:
    database.db_execute("UPDATE certificates SET revoked=1 WHERE id=?",
                        (ca["id"],))
    row, why = cv.find(ca["person_code"])
    T("گواهینامهٔ باطل پیدا می‌شود ولی علامت دارد",
      bool(row) and row.get("revoked") == 1)
    database.db_execute("UPDATE certificates SET revoked=0 WHERE id=?",
                        (ca["id"],))

# ══ ۶) تاریخ مرزی ══
T("۳۱ اسفند + ۱۲ ماه", J.add_months("1403/12/30", 12).startswith("1404"),
  J.add_months("1403/12/30", 12))
T("سال کبیسه ۲۹ اسفند", J.valid("1403/12/30"))
T("۳۰ اسفند غیرکبیسه نامعتبر", not J.valid("1404/12/30"))
T("تاریخ صفر", J.fmt("0000-00-00") == "—")
T("تاریخ آینده", J.days_left("1410/01/01") > 0)

# ══ ۷) رشتهٔ خیلی بلند ══
long = "ب" * 5000
iid3 = cc.create_issue(1, long, tid)
i3 = cc.get_issue(iid3)
T("عنوان بلند بریده می‌شود", len(i3.get("title") or "") <= 130,
  str(len(i3.get("title") or "")))
cc.set_value(iid3, "event", long)
v = cc.issue_values(cc.get_issue(iid3)).get("event", "")
T("مقدار پارامتر بریده می‌شود", len(v) <= 320, str(len(v)))

# ══ ۸) کد ملی تکراری ══
n_before = len(cc.shares(iid))
cc.fill_from_rows(iid, [{"full_name": "دو", "national_id":
                         "0023456787", "mobile": "", "extra": {}}])
T("گیرندهٔ تکراری اضافه نمی‌شود",
  len(cc.shares(iid)) == n_before, f"{n_before}→{len(cc.shares(iid))}")

print("═══ سناریوهای مرزی ═══\n")
for n, e in OK:
    print(f"  ✅ {n}")
for n, e in BAD:
    print(f"  🔴 {n}  {e}")
print(f"\n{len(OK)} موفق · {len(BAD)} ناموفق")
