@echo off
chcp 65001 >nul
title دکتر نورا
cd /d "%~dp0"
echo ============================================
echo    دکتر نورا - بررسی اتصال
echo ============================================
echo.
echo [1] بررسی پایه
echo [2] بررسی + تست واقعی رمز یکبار مصرف
echo [3] بررسی + تست فاکتور پرداخت
echo.
choice /C 123 /M "انتخاب کن"
if errorlevel 3 goto invoice
if errorlevel 2 goto otp
if errorlevel 1 goto basic

:basic
py doctor.py
goto end

:otp
set /p PHONE="شماره موبایل (مثال 09188164893): "
py doctor.py %PHONE%
goto end

:invoice
py doctor.py --test-invoice
goto end

:end
echo.
pause
