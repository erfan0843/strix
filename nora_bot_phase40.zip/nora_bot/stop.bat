@echo off
chcp 65001 >nul
title توقف ربات نورا
cd /d "%~dp0"
echo ============================================
echo    بستن همه نمونه های ربات
echo ============================================
echo.
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /IM py.exe >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1
if exist ".bot.lock" del /F /Q ".bot.lock" >nul 2>&1
if exist "__pycache__" rd /S /Q "__pycache__" >nul 2>&1
echo [+] همه نمونه ها بسته شدند
echo [+] قفل و کش پاک شد
echo.
echo حالا میتوانید run.bat را اجرا کنید
echo.
pause
