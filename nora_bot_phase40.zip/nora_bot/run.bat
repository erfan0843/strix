@echo off
chcp 65001 >nul
title ربات نورا - خط زندگی
cd /d "%~dp0"

echo ============================================
echo    ربات نورا - گروه فرهنگی خط زندگی
echo ============================================
echo.

py --version >nul 2>&1
if errorlevel 1 (
    echo [X] Python نصب نیست!
    echo     از python.org نصب کن و Add to PATH را بزن
    pause
    exit /b 1
)

REM ---- بستن نمونه‌های قبلی ربات ----
echo [*] بررسی نمونه‌های در حال اجرا...
set FOUND=0
for /f "tokens=2" %%p in ('tasklist /FI "IMAGENAME eq python.exe" /FO LIST 2^>nul ^| find "PID:"') do (
    set FOUND=1
)
if exist ".bot.lock" (
    echo [!] فایل قفل پیدا شد - ربات قبلی احتمالا باز است
    choice /C YN /M "همه نمونه های python را ببندم"
    if not errorlevel 2 (
        taskkill /F /IM python.exe >nul 2>&1
        taskkill /F /IM py.exe >nul 2>&1
        del /F /Q ".bot.lock" >nul 2>&1
        echo [+] بسته شد
        timeout /t 2 /nobreak >nul
    )
)

REM ---- پاکسازی کش ----
if exist "__pycache__" rd /S /Q "__pycache__" >nul 2>&1
if exist "tests\__pycache__" rd /S /Q "tests\__pycache__" >nul 2>&1

REM ---- فایل تنظیمات ----
if not exist ".env" (
    echo [!] فایل .env پیدا نشد
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo [+] فایل .env ساخته شد
        echo.
        echo     توکن و آیدی خود را داخلش بررسی کن
        notepad .env
        echo.
        pause
    )
)

REM ---- نصب پکیج‌ها ----
if not exist ".installed" (
    echo [*] نصب پکیج‌های مورد نیاز...
    py -m pip install --upgrade pip >nul 2>&1
    py -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [X] نصب ناموفق بود
        pause
        exit /b 1
    )
    echo ok > .installed
    echo [+] نصب کامل شد
    echo.
)

echo.
echo [*] اجرای ربات... (توقف با Ctrl+C)
echo ============================================
echo.
py main.py

echo.
echo ============================================
echo    ربات متوقف شد
echo ============================================
if exist ".bot.lock" del /F /Q ".bot.lock" >nul 2>&1
pause
