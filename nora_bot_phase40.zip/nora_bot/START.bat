@echo off
chcp 65001 >nul
title NORA - START
cd /d "%~dp0"

echo ============================================
echo    NORA BOT - START (all-in-one)
echo ============================================
echo.

REM ---------- 1) close old instances ----------
echo [1/3] Closing old instances...
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /IM py.exe >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1
if exist ".bot.lock" del /F /Q ".bot.lock" >nul 2>&1
if exist "__pycache__" rd /S /Q "__pycache__" >nul 2>&1
if exist "tests\__pycache__" rd /S /Q "tests\__pycache__" >nul 2>&1
echo     [+] done
echo.

REM ---------- 1.5) make .env if missing ----------
if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo     [+] .env created from .env.example
    )
)

REM ---------- 2) health check ----------
echo [2/3] Health check (doctor)...
echo.
py doctor.py
echo.
echo ============================================
choice /C YN /M "Start the bot now"
if errorlevel 2 goto skip

REM ---------- 3) run ----------
echo.
echo [3/3] Starting bot...  (stop with Ctrl+C)
echo ============================================
echo.
py main.py

:skip
echo.
if exist ".bot.lock" del /F /Q ".bot.lock" >nul 2>&1
echo Bot stopped.
pause
